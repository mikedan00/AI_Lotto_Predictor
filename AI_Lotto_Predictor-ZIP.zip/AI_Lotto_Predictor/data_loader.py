# 여기에 data_loader.py 전체 코드 붙여넣기
import os
from typing import Tuple, List, Dict, Optional

import numpy as np
import pandas as pd

from config import DATA_DIR, LOTTERIES, WINDOW


# ---------------------------------------------------------
# 1. Korean Lotto standardizer (for your exact header)
# ---------------------------------------------------------
def _standardize_kr_lotto(df_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Convert Korean Lotto file with columns:

        회차, 추첨일,
        당첨번호1..당첨번호6,
        보너스

    into standardized columns:

        round, date, n1..n6, bonus
    """
    df = df_raw.copy()

    # Strip spaces in column names just in case
    df.columns = [c.strip() for c in df.columns]

    rename_map = {
        "회차": "round",
        "추첨일": "date",
        "당첨번호1": "n1",
        "당첨번호2": "n2",
        "당첨번호3": "n3",
        "당첨번호4": "n4",
        "당첨번호5": "n5",
        "당첨번호6": "n6",
        "보너스": "bonus",
    }

    df = df.rename(columns=rename_map)

    # Keep only the columns we care about
    keep_cols = ["round", "date"] + [f"n{i}" for i in range(1, 7)] + ["bonus"]
    df = df[keep_cols]

    # Parse date: 'YYYY.MM.DD'
    df["date"] = pd.to_datetime(df["date"], format="%Y.%m.%d", errors="coerce")

    # Convert number columns to int
    num_cols = [f"n{i}" for i in range(1, 7)] + ["bonus"]
    for c in num_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Drop rows with missing numbers
    df = df.dropna(subset=num_cols)
    df[num_cols] = df[num_cols].astype(int)

    # Sort by round (oldest → newest)
    df["round"] = pd.to_numeric(df["round"], errors="coerce")
    df = df.dropna(subset=["round"])
    df["round"] = df["round"].astype(int)
    df = df.sort_values("round").reset_index(drop=True)

    return df


# ---------------------------------------------------------
# 2. Common column normalizer (for other lotteries)
# ---------------------------------------------------------
def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize generic lottery data:

      - 'date' → datetime
      - n1..nK, bonus → int
      - sort by 'round' if exists
    """
    df = df.copy()
    cols = df.columns.tolist()

    if "date" in cols:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")

    numeric_cols = [c for c in cols if c.startswith("n") or c == "bonus"]
    for c in numeric_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=numeric_cols)
    df[numeric_cols] = df[numeric_cols].astype(int)

    if "round" in df.columns:
        df["round"] = pd.to_numeric(df["round"], errors="coerce")
        df = df.dropna(subset=["round"])
        df["round"] = df["round"].astype(int)
        df = df.sort_values("round").reset_index(drop=True)

    return df


# ---------------------------------------------------------
# 3. File loader (CSV / Excel, with Korean encoding fallback)
# ---------------------------------------------------------
def _read_table(path: str) -> pd.DataFrame:
    ext = os.path.splitext(path)[1].lower()

    if ext == ".csv":
        # Try UTF-8 first, then cp949 (Excel in Korean Windows)
        try:
            return pd.read_csv(path, encoding="utf-8-sig")
        except UnicodeDecodeError:
            return pd.read_csv(path, encoding="cp949")
    elif ext in (".xls", ".xlsx"):
        return pd.read_excel(path)
    else:
        raise ValueError(f"Unsupported file extension: {ext}")


def load_lottery_data(
    kind: str = "kr_lotto",
    path: Optional[str] = None,
) -> Tuple[pd.DataFrame, int, int, int]:
    """
    Load lottery dataset and return:
      df, num_range, num_main, num_bonus

    kind: one of LOTTERIES keys ('kr_lotto', 'powerball', 'megamillions', ...)
    path: optional custom file path. If None, use DATA_DIR + default filename.
    """
    if kind not in LOTTERIES:
        raise ValueError(f"Unknown lottery kind: {kind}")

    meta = LOTTERIES[kind]
    if path is None:
        path = os.path.join(DATA_DIR, meta["filename"])

    df_raw = _read_table(path)

    # Apply appropriate standardization
    if kind == "kr_lotto":
        df = _standardize_kr_lotto(df_raw)
    else:
        # For other lotteries, assume columns already like:
        # round, date, n1..nK, bonus
        df = df_raw.copy()
        df.columns = [c.strip().lower() for c in df.columns]
        df = normalize_columns(df)

    return df, meta["num_range"], meta["num_main"], meta["num_bonus"]


# ---------------------------------------------------------
# 4. Supervised dataset creator (for deep learning)
# ---------------------------------------------------------
def create_supervised_data(
    df: pd.DataFrame,
    window: int = WINDOW,
    cols: Optional[List[str]] = None,
    flatten: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Convert time-series draws into supervised learning dataset.

    X[i] = draws[i : i+window]
    y[i] = draws[i+window]

    If flatten=True:
        X shape: (N, window * num_features) for DNN
    Else:
        X shape: (N, window, num_features) for LSTM/Transformer
    """
    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]
        cols = sorted(cols, key=lambda x: int(x[1:]))  # n1..n6

    data = df[cols].values
    num_features = data.shape[1]

    X_list: List[np.ndarray] = []
    y_list: List[np.ndarray] = []

    for i in range(len(data) - window):
        X_list.append(data[i : i + window])
        y_list.append(data[i + window])

    X = np.stack(X_list, axis=0)
    y = np.stack(y_list, axis=0)

    if flatten:
        X = X.reshape(X.shape[0], window * num_features)

    return X, y
