# 여기에 아까 내가 준 config.py 전체 코드를 그대로 붙여넣기
import os

# ==== Base directories (adjust BASE_DIR for your environment) ====
# In Google Colab + Google Drive you might use:
#   from google.colab import drive
#   drive.mount("/content/drive")
#   and then keep BASE_DIR as below.
BASE_DIR = "/content/drive/MyDrive/AI_Lotto_Predictor"

DATA_DIR = os.path.join(BASE_DIR, "data")
CHECKPOINT_DIR = os.path.join(BASE_DIR, "checkpoints")
RESULT_DIR = os.path.join(BASE_DIR, "results")

# Create folders if they don't exist (safe to call multiple times)
for _d in (DATA_DIR, CHECKPOINT_DIR, RESULT_DIR):
    os.makedirs(_d, exist_ok=True)

# ==== Lottery metadata ====
# filename is relative to DATA_DIR
LOTTERIES = {
    "kr_lotto": {
        "filename": "lotto_kr.csv",  # e.g. your Korean Lotto 6/45 CSV
        "num_range": 45,
        "num_main": 6,
        "num_bonus": 1,
    },
    "powerball": {
        "filename": "powerball.csv",
        "num_range": 69,
        "num_main": 5,
        "num_bonus": 1,
    },
    "megamillions": {
        "filename": "megamillions.csv",
        "num_range": 70,
        "num_main": 5,
        "num_bonus": 1,
    },
}

# ==== Global training settings ====
RANDOM_SEED = 42

# Window length (# of past draws used as input sequence for deep models)
WINDOW = 20

# Default train/validation split
TRAIN_RATIO = 0.8

# Default training hyper-parameters
BATCH_SIZE = 32
EPOCHS = 80

# Default model type: 'dnn', 'lstm', or 'transformer'
DEFAULT_MODEL = "transformer"
