# 여기에 deep_learning_model.py 전체 코드 붙여넣기
from typing import Tuple, Optional, Dict, Any

import numpy as np
import tensorflow as tf
from tensorflow.keras import Model, Sequential
from tensorflow.keras.layers import (
    Dense,
    LSTM,
    Dropout,
    Flatten,
    Input,
    LayerNormalization,
    MultiHeadAttention,
    GlobalAveragePooling1D,
)
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

from config import BATCH_SIZE, EPOCHS, CHECKPOINT_DIR


# ==== Model builders ====
def build_dnn(input_shape: Tuple[int, ...]) -> Model:
    """
    Simple DNN model.
    input_shape e.g. (window * num_features,)
    """
    model = Sequential(
        [
            Flatten(input_shape=input_shape),
            Dense(256, activation="relu"),
            Dropout(0.3),
            Dense(128, activation="relu"),
            Dropout(0.2),
            Dense(6, activation="linear"),  # predict 6 main numbers
        ]
    )
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


def build_lstm(input_shape: Tuple[int, ...]) -> Model:
    """
    LSTM-based sequence model.
    input_shape e.g. (window, num_features)
    """
    inputs = Input(shape=input_shape)
    x = LSTM(128, return_sequences=True)(inputs)
    x = Dropout(0.3)(x)
    x = LSTM(64)(x)
    x = Dropout(0.2)(x)
    outputs = Dense(6, activation="linear")(x)

    model = Model(inputs, outputs)
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


def build_transformer(
    input_shape: Tuple[int, ...],
    num_heads: int = 4,
    ff_dim: int = 128,
) -> Model:
    """
    Simple Transformer-style encoder with MultiHeadAttention.
    input_shape e.g. (window, num_features)
    """
    inputs = Input(shape=input_shape)
    x = LayerNormalization(epsilon=1e-6)(inputs)
    attn_output = MultiHeadAttention(
        num_heads=num_heads, key_dim=input_shape[-1]
    )(x, x)
    x = x + attn_output
    x = LayerNormalization(epsilon=1e-6)(x)
    x = Dense(ff_dim, activation="relu")(x)
    x = Dropout(0.2)(x)
    x = Dense(input_shape[-1])(x)
    x = GlobalAveragePooling1D()(x)
    outputs = Dense(6, activation="linear")(x)

    model = Model(inputs, outputs)
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


# ==== Training helper ====
def train_model(
    model: Model,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: Optional[np.ndarray] = None,
    y_val: Optional[np.ndarray] = None,
    epochs: int = EPOCHS,
    batch_size: int = BATCH_SIZE,
    model_name: str = "lotto_model",
    use_checkpoint: bool = True,
) -> Dict[str, Any]:
    """
    Generic training loop with optional validation and checkpointing.

    Returns
    -------
    history.history dict from Keras fit()
    """
    callbacks = [
        EarlyStopping(
            monitor="val_loss" if X_val is not None else "loss",
            patience=10,
            restore_best_weights=True,
        )
    ]

    if use_checkpoint:
        ckpt_path = f"{CHECKPOINT_DIR}/{model_name}.keras"
        callbacks.append(
            ModelCheckpoint(
                ckpt_path,
                monitor="val_loss" if X_val is not None else "loss",
                save_best_only=True,
            )
        )

    if X_val is not None and y_val is not None:
        history = model.fit(
            X_train,
            y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1,
        )
    else:
        history = model.fit(
            X_train,
            y_train,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1,
        )

    return history.history
