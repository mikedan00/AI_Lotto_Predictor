# 여기에 predictor.py 전체 코드 붙여넣기
from typing import List, Tuple, Sequence, Callable, Dict, Any

import numpy as np
import pandas as pd


# ==== Utility ====
def _flatten_numbers(df: pd.DataFrame, cols: Sequence[str]) -> np.ndarray:
    """
    Flatten draw-by-draw number columns into a 1D array.
    """
    return pd.concat([df[c] for c in cols]).values


# ==== Strategy 1: Frequency-based ====
def frequency_based(
    df: pd.DataFrame,
    num_range: int = 45,
    num_select: int = 6,
    weight_decay: float = 0.98,
    cols: Sequence[str] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Frequency-based strategy with exponential decay weights.

    Returns
    -------
    picks : np.ndarray
        Selected numbers (sorted ascending).
    freq : np.ndarray
        Weighted frequency array of shape (num_range + 1,).
    """
    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    rounds = len(df)
    weights = np.array([weight_decay ** (rounds - i - 1) for i in range(rounds)])

    freq = np.zeros(num_range + 1, dtype=float)

    for c in cols:
        values = df[c].values
        for idx, val in enumerate(values):
            if 1 <= val <= num_range:
                freq[val] += weights[idx]

    ranked = np.argsort(freq)[::-1]  # descending
    picks = np.sort(ranked[1 : num_select + 1])  # ignore index 0

    return picks, freq


# ==== Strategy 2: Pattern-based (sum + even/odd ratio) ====
def pattern_based(
    df: pd.DataFrame,
    num_range: int = 45,
    num_select: int = 6,
    trials: int = 5000,
    cols: Sequence[str] = None,
    random_state: int = 42,
) -> List[List[int]]:
    """
    Pattern-based sampling strategy using:
      - target sum (mean of historical sums)
      - even/odd ratio between 0.3 and 0.7
    """
    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    rng = np.random.default_rng(random_state)

    nums = _flatten_numbers(df, cols)
    # group by draw
    num_per_draw = len(cols)
    sums_per_draw = nums.reshape(-1, num_per_draw).sum(axis=1)
    target_sum = sums_per_draw.mean()

    candidates: List[List[int]] = []

    for _ in range(trials):
        pick = sorted(
            rng.choice(
                np.arange(1, num_range + 1),
                size=num_select,
                replace=False,
            ).tolist()
        )
        even_ratio = sum(1 for x in pick if x % 2 == 0) / num_select
        total = sum(pick)
        if 0.3 < even_ratio < 0.7 and abs(total - target_sum) < 20:
            candidates.append(pick)

    return candidates


# ==== Strategy 3: Simple math-based optimization (mean/variance) ====
def math_based(
    df: pd.DataFrame,
    num_range: int = 45,
    num_select: int = 6,
    trials: int = 3000,
    cols: Sequence[str] = None,
    random_state: int = 42,
) -> List[int]:
    """
    Math-based strategy: sample many combinations and keep the one
    whose mean/variance is closest to historical mean/variance.
    """
    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    rng = np.random.default_rng(random_state)

    nums = _flatten_numbers(df, cols)
    mu = nums.mean()
    var = nums.var()

    best_combo: List[int] = []
    best_score = float("inf")

    for _ in range(trials):
        pick = sorted(
            rng.choice(
                np.arange(1, num_range + 1),
                size=num_select,
                replace=False,
            ).tolist()
        )
        score = abs(np.mean(pick) - mu) + abs(np.var(pick) - var)
        if score < best_score:
            best_score = score
            best_combo = pick

    return best_combo


# ==== Strategy 4: Hot/Cold hybrid ====
def hot_cold_hybrid(
    df: pd.DataFrame,
    num_range: int = 45,
    num_select: int = 6,
    window: int = 20,
    ratio_hot: float = 0.5,
    cols: Sequence[str] = None,
) -> List[int]:
    """
    Hot/Cold hybrid: use recent 'window' draws to find hot and cold numbers.
    Select some from hot and some from cold.
    """
    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    recent = df.tail(window)
    nums_recent = _flatten_numbers(recent, cols)
    freq_recent = pd.Series(nums_recent).value_counts().sort_values(ascending=False)

    # hot: top K, cold: bottom K'
    k_hot = max(1, int(num_select * ratio_hot))
    hot = list(freq_recent.head(k_hot).index)

    remaining = num_select - len(hot)
    cold = []
    if remaining > 0:
        cold = list(freq_recent.tail(remaining).index)

    pool = sorted(set(hot + cold))
    if len(pool) < num_select:
        # if not enough unique numbers, fill from 1..num_range
        all_nums = set(range(1, num_range + 1))
        extra = sorted(list(all_nums - set(pool)))[: (num_select - len(pool))]
        pool.extend(extra)

    picks = sorted(np.random.choice(pool, size=num_select, replace=False).tolist())
    return picks


# ==== Interface helper ====
def generate_predictions(
    df: pd.DataFrame,
    strategies: Dict[str, Callable[..., Any]],
    num_range: int,
    num_select: int = 6,
) -> Dict[str, Any]:
    """
    Run multiple strategies and return their predictions in a dict.

    Parameters
    ----------
    df : DataFrame
        Lottery dataset.
    strategies : dict
        Mapping name -> function.
    num_range : int
        Maximum number for the lottery.
    num_select : int
        How many numbers to pick.

    Returns
    -------
    results : dict
        name -> prediction object (depends on each strategy).
    """
    results: Dict[str, Any] = {}

    for name, func in strategies.items():
        if name == "frequency":
            pred, _ = func(df, num_range=num_range, num_select=num_select)
            results[name] = pred
        else:
            results[name] = func(df, num_range=num_range, num_select=num_select)

    return results
