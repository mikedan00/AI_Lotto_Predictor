from typing import List, Optional

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _set_english_plot_style() -> None:
    # Use a Latin-safe font; avoids Korean glyph rendering attempts.
    mpl.rcParams["font.family"] = "DejaVu Sans"
    mpl.rcParams["axes.unicode_minus"] = False


def _english_only(text: str, fallback: str) -> str:
    # If non-ASCII exists (e.g., Hangul), replace with an English fallback.
    try:
        text.encode("ascii")
        return text
    except UnicodeEncodeError:
        return fallback


def plot_histogram(
    df: pd.DataFrame,
    cols: Optional[List[str]] = None,
    num_range: int = 45,
    title: str = "Number Frequency (All Draws)",
) -> None:
    _set_english_plot_style()

    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    title = _english_only(title, "Number Frequency (All Draws)")

    numbers = np.concatenate([df[c].dropna().to_numpy() for c in cols]).astype(int)

    plt.figure()
    plt.hist(numbers, bins=np.arange(1, num_range + 2) - 0.5, rwidth=0.8)
    plt.xticks(range(1, num_range + 1))
    plt.title(title)
    plt.xlabel("Lotto Number")
    plt.ylabel("Count")
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def plot_correlation_matrix(
    df: pd.DataFrame,
    cols: Optional[List[str]] = None,
    title: str = "Correlation Between Number Columns",
) -> None:
    _set_english_plot_style()

    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    title = _english_only(title, "Correlation Between Number Columns")

    corr = df[cols].corr()

    # English-only tick labels regardless of original column names (which may be Korean)
    tick_labels = [f"Ball {i+1}" for i in range(len(cols))]

    plt.figure()
    im = plt.imshow(corr, cmap="coolwarm", interpolation="none")
    plt.colorbar(im, fraction=0.046, pad=0.04, label="Correlation")
    plt.xticks(range(len(cols)), tick_labels, rotation=0)
    plt.yticks(range(len(cols)), tick_labels)
    plt.title(title)
    plt.tight_layout()
    plt.show()


def plot_moving_sum(
    df: pd.DataFrame,
    cols: Optional[List[str]] = None,
    window: int = 10,
    title: str = "Moving Average of Sum of Drawn Numbers",
) -> None:
    _set_english_plot_style()

    if cols is None:
        cols = [c for c in df.columns if c.startswith("n")]

    title = _english_only(title, "Moving Average of Sum of Drawn Numbers")

    sums = df[cols].sum(axis=1)
    ma = sums.rolling(window=window).mean()

    plt.figure()
    plt.plot(sums.index, sums.values, label="Sum (per draw)")
    plt.plot(ma.index, ma.values, label=f"Moving Average ({window} draws)", linestyle="--")
    plt.title(title)
    plt.xlabel("Draw Index (chronological order)")
    plt.ylabel("Sum of Winning Numbers")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
