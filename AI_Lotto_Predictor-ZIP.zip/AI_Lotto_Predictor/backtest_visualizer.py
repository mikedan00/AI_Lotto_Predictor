# 여기에 backtest_visualizer.py 전체 코드 붙여넣기
from typing import Callable, Dict, Any, List, Tuple, Sequence

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# ==== Helper: convert float outputs to valid lotto numbers ====
def _normalize_prediction_to_numbers(
    y_pred: Sequence[float],
    num_range: int = 45,
    num_select: int = 6,
) -> List[int]:
    """
    Convert a raw model output (length >= num_select) to
    a set of valid lottery numbers (1..num_range, no duplicates).
    """
    # Round and clip
    rounded = [int(round(v)) for v in y_pred]
    rounded = [min(max(1, v), num_range) for v in rounded]

    # Remove duplicates while preserving order
    uniq: List[int] = []
    for v in rounded:
        if v not in uniq:
            uniq.append(v)

    # If still fewer than num_select, fill with remaining numbers
    if len(uniq) < num_select:
        all_nums = list(range(1, num_range + 1))
        for v in all_nums:
            if v not in uniq:
                uniq.append(v)
            if len(uniq) >= num_select:
                break

    return sorted(uniq[:num_select])


# ==== Classical strategy backtest ====
def backtest_classical(
    df: pd.DataFrame,
    strategy_func: Callable[..., Any],
    lookback: int = 50,
    num_range: int = 45,
    num_select: int = 6,
    **kwargs,
) -> Tuple[float, List[int]]:
    """
    Rolling backtest for classical strategies.

    For each test index i (from lookback to len(df)-1):
      - use draws [0..i-1] as training history
      - predict numbers for draw i
      - compute hit count vs actual numbers

    Returns
    -------
    mean_hits : float
        Average hit count.
    hits : list of int
        Hit count sequence over the test period.
    """
    hits: List[int] = []

    for i in range(lookback, len(df)):
        train = df.iloc[:i]
        test_row = df.iloc[i]

        pred = strategy_func(
            train,
            num_range=num_range,
            num_select=num_select,
            **kwargs,
        )

        # Some strategies return (picks, freq), etc.
        if isinstance(pred, tuple):
            pred = pred[0]

        actual = [test_row[f"n{j}"] for j in range(1, num_select + 1)]
        hits.append(len(set(pred) & set(actual)))

    return float(np.mean(hits)), hits


# ==== Deep-learning backtest ====
def backtest_deep(
    model,
    X: np.ndarray,
    y_true: np.ndarray,
    num_range: int = 45,
    num_select: int = 6,
) -> Tuple[float, List[int]]:
    """
    Simple backtest for deep models using pre-built supervised dataset.

    Assumes:
      - X, y_true are aligned in time (chronological order)
      - y_true contains the true next-draw numbers (shape: (N, K))
      - model.predict(X) outputs same shape as y_true
    """
    y_pred = model.predict(X, verbose=0)
    hits: List[int] = []

    for i in range(len(y_true)):
        pred_nums = _normalize_prediction_to_numbers(
            y_pred[i],
            num_range=num_range,
            num_select=num_select,
        )
        true_nums = _normalize_prediction_to_numbers(
            y_true[i],
            num_range=num_range,
            num_select=num_select,
        )
        hits.append(len(set(pred_nums) & set(true_nums)))

    return float(np.mean(hits)), hits


# ==== Visualization ====
def plot_results(
    hits_list: List[List[int]],
    labels: List[str],
    title: str = "Hit Count Trend (Model Comparison)", # "Hit 수 추이 (모델 비교)",
) -> None:
    """
    Plot hit sequences from multiple models/strategies.
    """
    plt.figure(figsize=(10, 5))

    for hits, label in zip(hits_list, labels):
        arr = np.array(hits)
        plt.plot(arr, label=f"{label} (mean={arr.mean():.3f})")

    plt.title(title)
    plt.xlabel("Test Index")
    plt.ylabel("Hit Count")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
